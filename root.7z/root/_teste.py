a = 'Área 51'.encode('cp1252')

print(a)