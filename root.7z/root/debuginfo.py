#favor manter essa linha
g_isDebugMode=1

def SetDebugMode(isDebugMode):
	global g_isDebugMode
	g_isDebugMode=isDebugMode

def IsDebugMode():
	global g_isDebugMode
	return g_isDebugMode

