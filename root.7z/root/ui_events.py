from types import FunctionType
import _dbg as dbg

class UiEvents(dict):
    def GetEvent(self, event_name:str) -> FunctionType:
        if not self.get(event_name):
            return None
        return self.get(event_name).get('event')

    def GetArguments(self, event_name:str) -> tuple:
        if not self.get(event_name):
            return ()
        return self.get(event_name).get('args')

    def SetEvent(self, event_name:str, event, *args) -> None:
        self.update({event_name:{'event':event, 'args':args}})

    def ExecuteEvent(self, event_name:str) -> bool:
        event = self.GetEvent(event_name)
        if not event:
            return False
        args = self.GetArguments(event_name)
        dbg.TraceError(f'{event_name} func: {event} args: {args}')
        event(*args)